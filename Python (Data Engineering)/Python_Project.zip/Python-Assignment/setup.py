from setuptools import setup, find_packages

setup(
    name="data_processor_task",
    version="1.0.0",
    packages=find_packages(),
)