from my_processor.core import process_member_data, filter_members_by_email_domain
from my_processor.utils import MemberIterator

if __name__ == "__main__":
    # Test dataset including valid entries and the exact malformed sample from your instructions
    raw_members = [
        {"name": "M Raja Rao Reddy", "email": "raja@email.com", "phone": "9826808934"},
        {"name": "Jay Andrew", "email": "jay@gmail.com", "phone": "555-0102"},
        {"name": "No Name", "email": "jane.smith@...com", "phone": "555-0102"}
    ]
    
    # Process and build Member profiles
    processed_list = process_member_data(raw_members)
    
    # Demonstrate the custom Iterator implementation requirement
    print("\n Iterating through valid members using MemberIterator ")
    member_iterator = MemberIterator(processed_list)
    for member in member_iterator:
        print(member)
        
    # Demonstrate Lambda module function requirement
    print("\n Filtered Results (email.com) ")
    filtered = filter_members_by_email_domain(processed_list, "email.com")
    for member in filtered:
        print(member)