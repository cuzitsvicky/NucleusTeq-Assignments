import re

class InvalidMemberDataError(Exception):
    """Custom exception raised when member data fails validation."""
    pass

def validate_email(email: str) -> bool:
    """Validates an email address using basic regular expressions."""
    email_regex = r"^[\w\.-]+@[\w\.-]+\.\w+$"
    return bool(re.match(email_regex, email))

def validate_phone(phone: str) -> bool:
    """Validates an Indian 10-digit mobile number."""
    phone_regex = r"^[6-9]\d{9}$"
    return bool(re.match(phone_regex, phone))

class MemberIterator:
    """Custom iterator to safely loop over a collection of processed records."""
    def __init__(self, members_list):
        self._members = members_list
        self._index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self._index < len(self._members):
            result = self._members[self._index]
            self._index += 1
            return result
        raise StopIteration
