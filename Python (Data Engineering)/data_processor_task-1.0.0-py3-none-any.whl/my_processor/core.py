from my_processor.utils import validate_email, validate_phone, InvalidMemberDataError

class Member:
    def __init__(self, name: str, email: str, phone: str):
        self.name = name
        self.email = email
        self.phone = phone

    def __str__(self):
        return f"Member(Name: {self.name}, Email: {self.email}, Phone: {self.phone})"

def process_member_data(raw_data: list) -> list:
    """
    Cleans and processes raw member data into a list of Member objects.
    Uses Exception handling to catch malformed entries.
    """
    processed_members = []
    
    for item in raw_data:
        name = item.get("name", "").strip()
        email = item.get("email", "").strip()
        phone = item.get("phone", "").strip()
        
        print(f"Processing member: {name if name else 'Unknown'}... ", end="")
        
        try:
            if not name or not email or not phone:
                raise ValueError("Missing fields in data entry.")
                
            if not validate_email(email):
                raise InvalidMemberDataError(f"Invalid email for member '{name}'.")
                
            if not validate_phone(phone):
                raise InvalidMemberDataError(f"Invalid phone format for member '{name}'.")
            
            # Successfully validated
            member_obj = Member(name, email, phone)
            processed_members.append(member_obj)
            print("Validation Successful.")
            
        except (InvalidMemberDataError, ValueError) as e:
            print(f"Error: {e} Skipping.")
            
    print(f"\nSummary: {len(processed_members)} members processed successfully.")
    return processed_members

def filter_members_by_email_domain(members: list, domain: str) -> list:
    """Uses a lambda expression with filter() to find members with specific email domains."""
    return list(filter(lambda m: m.email.endswith(domain), members))
